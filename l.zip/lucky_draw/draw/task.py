# draw/management/commands/populate_tasks.py
from django.core.management.base import BaseCommand
from draw.models import Task

class Command(BaseCommand):
    help = 'Populate tasks for the Lucky Draw'

    def handle(self, *args, **kwargs):
        tasks = [
            {"name": "Follow us on Instagram", "description": "Follow our official INstagram account."},
            {"name": "Refer a Friend", "description": "Refer a friend to enter the draw."},
            {"name": "Subscribe to our YouTube", "description": "Subscribe to our YouTube channel."},
            {"name": "Follow us on Facebook", "description": "Follow our official Facebook page."},
        ]

        for task in tasks:
            Task.objects.get_or_create(**task)

        self.stdout.write(self.style.SUCCESS('Tasks populated successfully.'))

        