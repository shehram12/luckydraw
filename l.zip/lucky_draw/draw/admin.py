from django.contrib import admin

from .models import Task
from .models import Prize, Participant
from django.contrib import admin
from .models import  Participation, Prize, Winner, PasswordReset, SocialMediaLink
from django.contrib import admin

from .models import User, Ticket, Product


admin.site.register(Prize)
admin.site.register(Participant)
admin.site.register(Task)
admin.site.register(Participation)

admin.site.register(Winner)
admin.site.register(PasswordReset)
admin.site.register(SocialMediaLink)



admin.site.register(Ticket)
admin.site.register(Product)