# draw/urls.py
from django.urls import path
from .views import index, register_participant
from .views import complete_task
from . import views
from .views import sign_up
from django.urls import path
from django.urls import path
from .views import  signin_view


 


urlpatterns = [
    path('index/', index, name='index'),
    path('register/', register_participant, name='register'),
    path('register/', register_participant, name='register'),
  path('index', index, name='index'),
    path('register/', register_participant, name='register'),
    path(' signin_view/', signin_view , name=' signin_view'),
    path('participate/<int:prize_id>/', register_participant, name='participate'),

     path('complete/<int:task_id>/', complete_task, name='complete_task'),
      path('signin/', views.signin_view, name='signin'),
    path('send-otp/', views.send_otp, name='send_otp'),
    path('verify-otp/', views.verify_otp, name='verify_otp'),
    path('reset-password/', views.reset_password, name='reset_password'),
    path('sign-up/', sign_up, name='sign_up'),


    path("register/", views.register_user, name="register"),
    path("products/", views.product_list, name="products"),
    
    path('tasks/<int:participant_id>/', views.complete_task, name='complete_task'),
    path('enter-draw/<int:participant_id>/', views.enter_draw, name='enter_draw'),
    path('thank-you/', views.thank_you, name='thank_you'),

]
