from django.db import models

from django.db import models

from django.db import models

from django.db import models


from django.db import models
from django.db import models
from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import User

from django.db import models
from django.db import models
from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin
from django.contrib.auth.models import User

from django.db import models

class Participant(models.Model):
    username = models.CharField(max_length=255, unique=True)  # Ensure unique usernames
    email = models.EmailField(unique=True)  # Email field for contact
    registered_at = models.DateTimeField(auto_now_add=True)  # When the user registered
    is_signed_up = models.BooleanField(default=False)  # Whether they signed up
    tasks_completed = models.IntegerField(default=0)  # Track number of tasks completed
    entered_draw = models.BooleanField(default=False)  # Whether they entered the draw

    def __str__(self):
        return self.username

class Prize(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(upload_to='prizes/')
    value = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.title

class Participation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    prize = models.ForeignKey(Prize, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.prize.title}"




class Ticket(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    # Other fields...


class Transaction(models.Model):
    wallet_address = models.CharField(max_length=42)  # Ethereum address
    transaction_hash = models.CharField(max_length=66, unique=True)  # Ethereum transaction hash
    amount = models.DecimalField(max_digits=18, decimal_places=10)  # Amount in ETH
    status = models.CharField(max_length=20, default="pending")  # pending, successful, failed
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.wallet_address} - {self.transaction_hash}"


class Payment(models.Model):
    transaction_hash = models.CharField(max_length=66, unique=True)  # Ethereum transaction hash
    wallet_address = models.CharField(max_length=42)  # Ethereum wallet address
    amount = models.DecimalField(max_digits=10, decimal_places=4)  # ETH amount
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.wallet_address} - {self.transaction_hash}"




# Tickets Model
class Ticket(models.Model):
    ticket_number = models.CharField(max_length=20, unique=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="tickets")
    created_at = models.DateTimeField(auto_now_add=True)

# Products Model
class Product(models.Model):
    product_name = models.CharField(max_length=100)
    product_description = models.TextField()
    product_image = models.ImageField(upload_to="product_images/")
    product_price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    created_at = models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return self.product_name


class Prize(models.Model):
    name = models.CharField(max_length=255)
    value = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return self.name

class Participant(models.Model):
    email = models.EmailField(unique=True)
    ticket_number = models.CharField(max_length=20, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email
    # draw/models.py


class Participant(models.Model):
    email = models.EmailField(unique=True)
    ticket_number = models.CharField(max_length=20, unique=True)
    tasks_completed = models.JSONField(default=list)  # Store completed tasks
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email

class Task(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    completed_by = models.ManyToManyField(Participant, related_name='completed_tasks', blank=True)

    def __str__(self):
        return self.name
    

    class User(models.Model):
      first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    username = models.CharField(max_length=50, unique=True)
    email = models.EmailField(unique=True)
    password_hash = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)

class Participation(models.Model):
    
    ticket_number = models.CharField(max_length=20, unique=True)
    task_completed = models.BooleanField(default=False)
    purchase_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    created_at = models.DateTimeField(auto_now_add=True)

class Prize(models.Model):
    prize_name = models.CharField(max_length=100)
    prize_description = models.TextField()
    prize_image_url = models.URLField(max_length=255, null=True, blank=True)
    prize_value = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    available = models.BooleanField(default=True)

class Winner(models.Model):
    
    prize = models.ForeignKey(Prize, on_delete=models.CASCADE)
    draw_date = models.DateField()

class PasswordReset(models.Model):
    
    reset_token = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()

class SocialMediaLink(models.Model):
    platform_name = models.CharField(max_length=50)
    platform_url = models.URLField(max_length=255)
