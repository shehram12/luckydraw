from django.shortcuts import render


from django.shortcuts import render, redirect
from .forms import ParticipantForm
from .models import Prize
from django.shortcuts import render, redirect
from .forms import ParticipantForm
from .models import Task, Participant

from django.contrib import messages
from django.http import HttpResponseRedirect
from django.urls import reverse


from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages

import random
from django.core.mail import send_mail
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.models import User
from .forms import UserRegistrationForm
import uuid
from django.shortcuts import render, redirect
from .models import User, Ticket, Product
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login+
from django.contrib import messages
from .forms import UserRegistrationForm
from .models import Prize, Participation
from django.shortcuts import render, redirect
from .models import Participant
from .forms import ParticipantForm

# Handle user registration
def sign_up(request):
    if request.method == 'POST':
        form = ParticipantForm(request.POST)
        if form.is_valid():
            participant = form.save()
            participant.is_signed_up = True
            participant.save()
            return redirect('tasks')  # Redirect to the task page where they can complete tasks
    else:
        form = ParticipantForm()
    return render(request, 'sign_up.html', {'form': form})

# Handle task completion (Increase task completion count)
def complete_task(request, participant_id):
    participant = Participant.objects.get(id=participant_id)
    participant.tasks_completed += 1
    participant.save()
    return redirect('tasks')

# Handle entering the draw
def enter_draw(request, participant_id):
    participant = Participant.objects.get(id=participant_id)
    if participant.tasks_completed > 0:  # Ensure they completed at least one task
        participant.entered_draw = True
        participant.save()
        return redirect('thank_you')  # Redirect to a thank you page after entering
    else:
        return redirect('tasks')  # If they haven't completed tasks, redirect back to tasks page

# Thank you page after entering the draw
def thank_you(request):
    return render(request, 'thank_you.html')


def index(request):
    prizes = Prize.objects.all()
    return render(request, 'draw/index.html', {'prizes': prizes})

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            messages.success(request, 'Registration successful. You can now log in.')
            return redirect('signin')
    else:
        form = UserRegistrationForm()
    return render(request, 'draw/register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            signin_view(request, user)
            return redirect('index')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'draw/signin.html')

def participate(request, prize_id):
    prize = Prize.objects.get(id=prize_id)
    if request.method == 'POST':
        participation = Participation(user=request.user, prize=prize)
        participation.save()
        messages.success(request, 'You have successfully entered the draw!')
        return redirect('signin')
    return render(request, 'draw/participate.html', {'prize': prize})


# Generate Ticket for User
def generate_ticket(user):
    ticket_number = f"TICKET_{uuid.uuid4().hex[:8].upper()}"
    ticket = Ticket.objects.create(ticket_number=ticket_number, user=user)
    return ticket

# User Registration with Ticket Generation
def register_user(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]
        first_name = request.POST["first_name"]
        last_name = request.POST["last_name"]

        # Create user
        user = User.objects.create_user(
            username=username,
            email=email,
            password=password,
            first_name=first_name,
            last_name=last_name,
        )

        # Generate ticket
        ticket = generate_ticket(user)

        return redirect("index")
    return render(request, "register.html")

  # Fetch Products
def product_list(request):
    products = Product.objects.all()
    return render(request, "products.html", {"products": products})


def sign_up(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            messages.success(request, "Account created successfully. You can now log in.")
            return redirect('sign_in')  # Replace with the sign-in page URL
    else:
        form = UserRegistrationForm()

    return render(request, 'authentication/sign_up.html', {'form': form})








otp_storage = {}  # Temporary storage for OTPs (use a secure method in production)

@csrf_exempt
def send_otp(request):
    if request.method == "POST":
        data = json.loads(request.body)
        email = data.get('email')

        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return JsonResponse({'error': 'Email not found'}, status=404)

        otp = str(random.randint(1000, 9999))
        otp_storage[email] = otp  # Save OTP (use a secure session-based or DB method)

        # Send OTP via email
        send_mail(
            'Password Reset OTP',
            f'Your OTP is {otp}',
            'noreply@example.com',
            [email],
        )

        return JsonResponse({'success': 'OTP sent to your email'})

    return JsonResponse({'error': 'Invalid request'}, status=400)


@csrf_exempt
def verify_otp(request):
    if request.method == "POST":
        data = json.loads(request.body)
        email = data.get('email')
        otp = data.get('otp')

        if email in otp_storage and otp_storage[email] == otp:
            del otp_storage[email]  # Clear OTP after successful verification
            return JsonResponse({'success': 'OTP verified'})

        return JsonResponse({'error': 'Invalid OTP'}, status=400)

    return JsonResponse({'error': 'Invalid request'}, status=400)


@csrf_exempt
def reset_password(request):
    if request.method == "POST":
        data = json.loads(request.body)
        email = data.get('email')
        new_password = data.get('new_password')

        try:
            user = User.objects.get(email=email)
            user.set_password(new_password)
            user.save()
            return JsonResponse({'success': 'Password successfully updated'})
        except User.DoesNotExist:
            return JsonResponse({'error': 'Email not found'}, status=404)

    return JsonResponse({'error': 'Invalid request'}, status=400)





def signin_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('index')  # Change to your dashboard/home URL
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'draw/signin.html')




def home(request):
    prizes = Prize.objects.all()
    return render(request, 'index.html', {'prizes': prizes})

def register_participant(request):
    if request.method == 'POST':
        form = ParticipantForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = ParticipantForm()
    return render(request, 'draw/register.html', {'form': form})
# draw/views.py


def task_list(request):
    tasks = Task.objects.all()
    return render(request, 'draw/task_list.html', {'tasks': tasks})

def complete_task(request, task_id):
    task = Task.objects.get(id=task_id)
    if request.method == 'POST':
        email = request.POST.get('email')  # Get the participant's email
        try:
            participant = Participant.objects.get(email=email)
            task.completed_by.add(participant)
            return redirect('task_list')
        except Participant.DoesNotExist:
            return redirect('task_list')  # Handle case where participant does not exist
    return redirect('task_list')
# draw/views.py

def complete_task(request, task_id):
    task = Task.objects.get(id=task_id)
    if request.method == 'POST':
        email = request.POST.get('email')  # Get the participant's email
        try:
            participant = Participant.objects.get(email=email)
            task.completed_by.add(participant)
            messages.success(request, f'You have successfully completed the task: {task.name}!')
            return redirect('task_list')
        except Participant.DoesNotExist:
            messages.error(request, 'Participant not found. Please register first.')
            return redirect('task_list')
    return redirect('task_list')
def complete_task(request, task_id):
    task = Task.objects.get(id=task_id)
    task.completed = True
    task.save()
    return HttpResponseRedirect(reverse('task_page'))